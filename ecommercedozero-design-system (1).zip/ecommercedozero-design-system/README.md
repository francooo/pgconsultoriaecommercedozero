# Pacote da página — ecommercedozero

Este diretório contém a página de consultoria, seus estilos, tokens visuais, biblioteca SVG, símbolo de marca, favicon e documento de design system.

Os arquivos de marca ficam em `assets/brand/`; a página já referencia o favicon vetorial e as versões de dispositivo.

## Prévia local

Abra `index.html` em um navegador. Para visualizar a biblioteca de ícones, abra `icons-preview.html`. As fontes web usam Google Fonts; sem internet, serão usadas fontes de fallback.

Os CTAs e o link de WhatsApp permanecem configurados conforme a página atual. Consulte `DESIGN-SYSTEM.md` para regras visuais, componentes e orientações de conteúdo.
